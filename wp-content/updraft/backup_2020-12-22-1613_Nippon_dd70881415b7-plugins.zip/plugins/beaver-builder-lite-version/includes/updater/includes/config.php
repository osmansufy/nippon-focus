<?php

$config = array(
	'fl-automator' => WP_CONTENT_DIR . '/themes/fl-automator/includes/updater-config.php',
	'fl-builder'   => WP_PLUGIN_DIR . '/fl-builder/includes/updater-config.php',
	'bb-theme'     => WP_CONTENT_DIR . '/themes/bb-theme/includes/updater-config.php',
	'bb-plugin'    => WP_PLUGIN_DIR . '/bb-plugin/includes/updater-config.php',
);
