$(document).ready(function() {
    $("#lightGallery").lightGallery({
        mode:"fade",
        speed:800,
        caption:true,
        desc:true,
        mobileSrc:true
    });
});