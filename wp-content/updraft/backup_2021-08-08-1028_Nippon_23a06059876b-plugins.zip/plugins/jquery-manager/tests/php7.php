<?php
// Only possible in PHP 7
define( 'WP_JQUERY_MANAGER_PLUGIN_JQUERY_SETTINGS', (array) get_option( 'wp_jquery_manager_plugin_jquery_settings' ) );
define( 'WP_JQUERY_MANAGER_PLUGIN_JQUERY_MIGRATE_SETTINGS', (array) get_option( 'wp_jquery_manager_plugin_jquery_migrate_settings' ) );
